<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<?php
if(isset($_GET['first_num'])){
    $first_num =$_GET['first_num'];
    $second_num =$_GET['second_num'];
    $operation = $_GET['operation'];
    $url ='index.php'.'?'.'first_num='.$_GET['first_num'].'&&'.'second_num='.$_GET['second_num'].'operation='.$_GET['operation'];
}
else{
    $first_num =null;
    $second_num =null;
}
?>
    <form action="/index.php" method="get">
    первое число: <input type="number" name="first_num" value=<?php echo $first_num ?> >
     <br>
     второе число: <input type="number" name="second_num" value=<?php echo $second_num ?> >
        <br>
     операция : <label>
            <select name="operation">
                   <option>+</option>
                   <option>-</option>
                   <option>*</option>
                   <option>/</option>
                       </select>
        </label>
        <br>
    <button type="submit"> Решить </button>
    </form>



    <?php
    function answer($first_num,$second_num,$operation){
        if ($operation == '+') {
            return $first_num + $second_num;
        }
        if ($operation == '-') {
            return $first_num - $second_num;
        }
        if ($operation == '*') {
            return $first_num * $second_num;
        }
        if ($operation == '/') {
            return $first_num / $second_num;
        }
    }
    ?>


    <br>
    <?php    echo $_GET['first_num'].$_GET['operation'].$_GET['second_num'].'='.answer($_GET['first_num'],$_GET['second_num'],$_GET['operation']);

    ?>
</body>
</html>