<?php
function discrim($a,$b,$c){
    return $b**2-4*$a*$c;
}
assert(0 ==discrim(0,0,0));
assert(-23 ==discrim(2,1,3));
assert(25 ==discrim(3,-5,0));

function genderName($name){
    $s = mb_substr($name,-1,1);
    switch (true){
        case $s=='а':
            echo ('имя женское,наверное');
            return 'female';
        case $s== 'н'|| $s=='г'|| $s=='й':
           echo (' имя мужское,наверное');
            return 'male';
        default:
            echo 'даже представить не могу чье это имя';
            return 'null';
    }
}
/*assert('female'==genderName('Анна'));
assert('female'==genderName('Оксана'));
assert('male'==genderName('Олег'));
assert('male'==genderName('Сергей'));
assert('null'==genderName('янь'));*/
