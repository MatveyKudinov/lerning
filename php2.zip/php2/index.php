<!doctype html>
<html lang="ru">
<head>

    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>php</title>
</head>
<body>
    <h1>Дискриминант</h1>
    <div>
            <?php
             include __DIR__.'\functions.php';
            $name ='анна';
             genderName($name);
         ?>
    </div>
     <div>
         <?php

        echo('Дискриминант равен '.discrim(4,5,2));
         ?>

<div>
    <?php

    for ($x = 0; $x <=1; $x++) {

    for($y =0; $y <=1;$y++) {
        echo $x.'|';
        echo $y.'|';
        $c = $x && $y;
         echo (int)$c;
        echo("<br/>");
    }
    }
    echo("<br/>");
    ?>
</div>
    <?php

    for ($x = 0; $x <=1; $x++) {

        for($y =0; $y <=1;$y++) {
            echo $x.'|';
            echo $y.'|';
            $c = $x || $y;
            echo (int)$c;
           echo("<br/>");
        }
    }
    echo("<br/>");
    ?>
    <div>
        <?php

        for ($x = 0; $x <=1; $x++) {

            for($y =0; $y <=1;$y++) {
                echo $x.'|';
                echo $y.'|';
                $c = $x xor $y;
                echo (int)$c;
                echo("<br/>");
            }
        }
        echo("<br/>");
        ?>
    </div>
         
</body>
</html>